package com.autooptimize;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.ParticleStatus;

/**
 * AutoOptimize: sin configuracion.
 *
 * Cada 5 segundos mira tus FPS. Si bajan de LOW_FPS reduce particulas y distancia de
 * entidades en pasos; si suben de HIGH_FPS devuelve tus ajustes originales poco a poco.
 * Al salir del mundo restaura todo a como lo tenias.
 */
public final class AutoOptimizeClient implements ClientModInitializer {

    private static final int CHECK_EVERY_TICKS = 100; // 100 ticks = 5 segundos
    private static final int LOW_FPS = 50;
    private static final int HIGH_FPS = 100;
    private static final int MAX_LEVEL = 2;

    private int ticks = 0;
    private int level = 0; // 0 = tus ajustes, 1 = reducido, 2 = minimo

    private ParticleStatus originalParticles;
    private double originalEntityDistance;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }

    private void onTick(Minecraft mc) {
        if (mc.options == null) {
            return;
        }

        // Fuera de un mundo: restaurar tus ajustes si habiamos cambiado algo.
        if (mc.level == null) {
            ticks = 0;
            if (level > 0) {
                apply(mc, 0);
            }
            return;
        }

        if (++ticks < CHECK_EVERY_TICKS) {
            return;
        }
        ticks = 0;

        int fps = mc.getFps();
        if (fps <= 0) {
            return;
        }

        if (fps < LOW_FPS && level < MAX_LEVEL) {
            apply(mc, level + 1);
        } else if (fps > HIGH_FPS && level > 0) {
            apply(mc, level - 1);
        }
    }

    private void apply(Minecraft mc, int newLevel) {
        if (level == 0 && newLevel > 0) {
            // Guardar tus ajustes antes del primer cambio.
            originalParticles = mc.options.particles().get();
            originalEntityDistance = mc.options.entityDistanceScaling().get();
        }

        switch (newLevel) {
            case 0 -> {
                if (originalParticles != null) {
                    mc.options.particles().set(originalParticles);
                    mc.options.entityDistanceScaling().set(originalEntityDistance);
                }
            }
            case 1 -> {
                mc.options.particles().set(ParticleStatus.DECREASED);
                mc.options.entityDistanceScaling().set(Math.min(originalEntityDistance, 0.75));
            }
            default -> {
                mc.options.particles().set(ParticleStatus.MINIMAL);
                mc.options.entityDistanceScaling().set(Math.min(originalEntityDistance, 0.5));
            }
        }

        level = newLevel;
    }
}
