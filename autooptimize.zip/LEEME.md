# AutoOptimize (Minecraft 26.3, Fabric)

Mod de cliente sin configuracion. Cada 5 segundos revisa tus FPS: si bajan de 50 reduce
particulas y distancia de entidades; si suben de 100 los devuelve a como los tenias.
Al salir del mundo restaura tus ajustes. Esta pensado para usarse **junto a Sodium**, no en su lugar.

## Como obtener el .jar (una sola vez)

1. Crea una cuenta gratis en https://github.com si no tienes.
2. Crea un repositorio nuevo (boton "New"), publico o privado.
3. Sube TODO el contenido de esta carpeta (incluida la carpeta oculta `.github`).
   En la web: "Add file" > "Upload files" y arrastra todo. Asegurate de que `.github/workflows/build.yml` quede subido.
4. Ve a la pestana **Actions**, entra a "Compilar mod" y espera a que termine (unos minutos).
5. Abajo, en **Artifacts**, descarga `AutoOptimize-jar`. Dentro esta el `.jar`.
6. Copialo a la carpeta `mods` de tu instancia de Fabric 26.3, junto con Fabric API y Sodium.

## Si la compilacion falla

Abre el paso que salio en rojo, copia el error y pegaselo a Claude. Lo mas probable es un nombre de
metodo de Minecraft 26.3 que haya que ajustar.
